Using-jsTree
============

jsTree is a jquery tree plugin and can be used to show a treeview structure in a web page. It can be used to show heirarchial data in a page. Tree can be nested as many levels deep as you wish.

Various operations are possible when using jsTree. Some of it are:

* Expand a node to show all its children.
* Collapse a node.
* Handle click action on a node.

This project contains the code for a simple example I could think for showing jsTree in action. Step by step explanation for this project can be found at a [blog](http://agiliq.com/blog/2011/10/how-use-jstree/) on our site.
